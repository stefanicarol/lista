import 'package:cloud_firestore/cloud_firestore.dart';

class TodoModel {
  String mercado;
  bool check;
  final DocumentReference reference;

  TodoModel({this.reference, this.mercado, this.check});

  factory TodoModel.fromDocuments(DocumentSnapshot doc) {
    return TodoModel(mercado: doc['Mercado'], reference: doc.reference);
  }
}
