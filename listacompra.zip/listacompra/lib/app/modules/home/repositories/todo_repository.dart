import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:listacompra/app/modules/home/models/todo_model.dart';
import 'package:listacompra/app/modules/home/repositories/todo_repository_interface.dart';

import 'todo_repository_interface.dart';

class TodoRepository implements ITodoRepository {
  final FirebaseFirestore firestore;

  TodoRepository(this.firestore);

  @override
  Stream<List<TodoModel>> getTodos() {
    return firestore.collection('lista').snapshots().map((query) {
      return query.docs.map((doc) {
        return TodoModel.fromDocuments(doc);
      }).toList();
    });
  }
}
